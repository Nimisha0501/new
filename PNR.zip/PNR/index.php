<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Prinu Restaurant</title>
    <link rel="icon" type="image/x-icon" href="1.png">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500&display=swap" rel="stylesheet">

    <!-- Styles -->
    <style>
        html,
        body {
            background-color: #001524;
            color: #CED3DC;
            font-family: 'Baloo 2', cursive;
            font-weight: 100;
            height: 100vh;
            margin: 0;
        }
        

        .logo img {
            position: relative;
            width: 16em;
            height: 15em;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #CED3DC;
            padding: 0 25px;
            font-size: 16px;
            font-weight: 500;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="flex-center position-ref full-height">
        <div class="content">
            <div class="logo">
               <img src="1.png" alt="">
            </div>
            <div class="title m-b-md">
               Prinu Restaurant
            </div>

            <div class="links">
			
                <a href="Restro/admin/">Admin Log In</a>
                <a href="Restro/cashier/">Cashier Log In</a>
                <a href="Restro/customer">Customer Log In</a>
            </div>
        </div>
    </div>
</body>

</html>